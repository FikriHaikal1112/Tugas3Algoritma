
package com.hitungbangunruang;
import java.util.Scanner;

// Muh. Fikri Haikal

public class Kerucut {
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        
        int Jarijari,Tinggi,Garispelukis ;
        double Phi, Volume, Luas;
        Phi = 3.14 ;
        
        
        System.out.println("menghitung Luas & Volume Kerucut");
        System.out.print("Masukkan Jarijari Kerucut = ");
        Jarijari= userInput.nextInt();
        
        System.out.print("Masukkan Tinggi Kerucut = " );
        Tinggi= userInput.nextInt();
        
        System.out.print("Masukkan Garispelukis Kerucut = ");
        Garispelukis= userInput.nextInt();
       
        Luas = Phi * Jarijari * ( Jarijari + Garispelukis );
        Volume = Phi * 1/3 * Jarijari * Jarijari + Tinggi ;
        
        System.out.println("Luas Kerucut = " + Luas);
        System.out.println("Volume Kerucut = " + Volume);
        
         
 
        
             
    }
}
