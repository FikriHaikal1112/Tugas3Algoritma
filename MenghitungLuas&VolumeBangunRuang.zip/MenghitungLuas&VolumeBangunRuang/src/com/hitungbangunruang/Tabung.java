/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hitungbangunruang;
import java.util.Scanner;

// Muh. Fikri Haikal

public class Tabung {
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        
        double phi =3.14, jarijari, tinggi ,diameter ,luas ,volume ;
       
        
        System.out.println("menghitung Luas & Volume Tabung");
                
        System.out.print("Masukkan jarijari Tabung = ");
        jarijari = userInput.nextInt();
        

                
        System.out.print("Masukkan tinggi Tabung  = ");
        tinggi = userInput.nextInt();
        
                
        luas = 2* phi * jarijari* (jarijari+tinggi);
        volume = phi * jarijari *jarijari * tinggi;
        System.out.println("Luas tabung = " + luas);
        System.out.println("Volume tabung = " + volume);
    }
}


