
package com.hitungbangunruang;
import java.util.Scanner;

// Muh. Fikri Haikal

public class Balok {
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        
        int Panjang, Lebar, Tinggi, Luas, Volume;
        
        System.out.println("menghitung Luas & Volume Balok");
                
        System.out.print("Masukkan Panjang Balok = ");
        Panjang = userInput.nextInt();
                
        System.out.print("Masukkan Lebar Balok = ");
        Lebar = userInput.nextInt();
        
        System.out.print("Masukkan Panjang Balok = ");
        Tinggi = userInput.nextInt();
        
        Luas = 2* (Panjang * Lebar + Panjang * Tinggi + Lebar * Tinggi );
        Volume = Panjang * Lebar * Tinggi;
        System.out.println("Luas Balok = " + Luas);
        System.out.println("Volume Balok = " + Volume);
    }
}
